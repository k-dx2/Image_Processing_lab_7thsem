import matplotlib.pyplot as plt
import matplotlib.image as img
img1=img.imread("../Desktop/labimg.jpg")
plt.show(img1)

